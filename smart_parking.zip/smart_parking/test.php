<?php

include 'config.php';

echo "DATABASE = ".$db."<br>";
echo "KONEKSI BERHASIL";