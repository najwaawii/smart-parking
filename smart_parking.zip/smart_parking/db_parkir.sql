-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2026 at 09:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_parkir`
--

-- --------------------------------------------------------

--
-- Table structure for table `log_anpr`
--

CREATE TABLE `log_anpr` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_anpr`
--

INSERT INTO `log_anpr` (`id`) VALUES
(1);

-- --------------------------------------------------------

--
-- Table structure for table `slot_parkir`
--

CREATE TABLE `slot_parkir` (
  `id` int(11) NOT NULL,
  `nomor_slot` varchar(255) DEFAULT NULL,
  `plat_nomor` varchar(255) DEFAULT NULL,
  `status` enum('kosong','terisi') DEFAULT NULL,
  `waktu_keluar` datetime DEFAULT NULL,
  `waktu_masuk` datetime DEFAULT NULL,
  `jarak` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slot_parkir`
--

INSERT INTO `slot_parkir` (`id`, `nomor_slot`, `plat_nomor`, `status`, `waktu_keluar`, `waktu_masuk`, `jarak`) VALUES
(1, 'A1', 'W 805 TOP', 'terisi', '2026-05-24 19:06:38', '2026-05-21 10:22:16', NULL),
(2, 'A2', 'UNKNOWN', 'kosong', '2026-05-24 16:35:08', '2026-05-24 16:34:43', NULL),
(3, 'A3', 'UNKNOWN', 'kosong', '2026-05-28 21:34:37', '2026-05-28 21:34:36', NULL),
(4, 'A4', 'UNKNOWN', 'kosong', '2026-06-11 13:58:51', '2026-06-11 13:58:49', NULL),
(5, 'A5', 'UNKNOWN', 'kosong', '2026-05-24 17:11:45', '2026-05-24 17:11:39', NULL),
(6, 'A6', 'UNKNOWN', 'kosong', '2026-05-24 18:43:17', '2026-05-24 18:43:08', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log_anpr`
--
ALTER TABLE `log_anpr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slot_parkir`
--
ALTER TABLE `slot_parkir`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log_anpr`
--
ALTER TABLE `log_anpr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slot_parkir`
--
ALTER TABLE `slot_parkir`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
