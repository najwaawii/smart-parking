<?php
header('Content-Type: application/json');
include '../config.php';

$sqlLast = "SELECT plat_nomor, waktu_deteksi
            FROM log_anpr
            ORDER BY waktu_deteksi DESC
            LIMIT 1";
$rLast = $conn->query($sqlLast);
$last  = ($rLast && $rLast->num_rows > 0) ? $rLast->fetch_assoc() : null;

echo json_encode([
    'last' => $last,
    'logs' => []
]);
