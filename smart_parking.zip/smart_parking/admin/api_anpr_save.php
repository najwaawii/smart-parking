<?php
header('Content-Type: application/json');
include '../config.php';

$plat = $_POST['plat'] ?? null;

if (!$plat) {
    echo json_encode(['success' => false, 'message' => 'plat kosong']);
    exit;
}

$now   = date('Y-m-d H:i:s');
$pesan = "ANPR SUCCESS: Plat terbaca [$plat]. Silakan cari parkir.";

$sql = "INSERT INTO log_anpr (plat_nomor, waktu_deteksi, pesan)
        VALUES ('$plat', '$now', '$pesan')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>
