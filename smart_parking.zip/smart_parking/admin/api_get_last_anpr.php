<?php

include "../config.php";

header("Content-Type: application/json");

$query = $conn->query("
    SELECT plat_nomor, nomor_slot, waktu_masuk
    FROM slot_parkir
    ORDER BY waktu_masuk DESC
    LIMIT 1
");

if($query && $query->num_rows > 0){
    
    $data = $query->fetch_assoc();

    echo json_encode([
        "success" => true,
        "plat_nomor" => $data['plat_nomor'],
        "nomor_slot" => $data['nomor_slot'],
        "waktu_masuk" => $data['waktu_masuk']
    ]);

} else {

    echo json_encode([
        "success" => false
    ]);
}