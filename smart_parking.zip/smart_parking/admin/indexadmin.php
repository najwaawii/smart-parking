<?php
include "../config.php";
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Smart Parking Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Inter',sans-serif;
    background:
    radial-gradient(circle at top,#0f172a,#020617 65%);
    color:white;
    overflow-x:hidden;
}

/* SCROLLBAR */

::-webkit-scrollbar{
    width:8px;
}

::-webkit-scrollbar-thumb{
    background:#2563eb;
    border-radius:20px;
}

/* SIDEBAR */

.sidebar{
    width:230px;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    background:rgba(2,6,23,0.95);
    border-right:1px solid rgba(255,255,255,0.05);
    padding:24px 18px;
}

.logo{
    font-size:28px;
    font-weight:800;
    line-height:1.2;
    margin-bottom:50px;
}

.logo span{
    color:#22c55e;
}

.menu-title{
    color:#64748b;
    font-size:11px;
    letter-spacing:4px;
    margin-bottom:16px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:10px;
    text-decoration:none;
    color:#dbeafe;
    padding:14px 16px;
    border-radius:16px;
    margin-bottom:12px;
    transition:0.3s;
    font-size:14px;
    font-weight:600;
}

.menu a:hover,
.menu a.active{
    background:
    linear-gradient(
        135deg,
        #2563eb,
        #3b82f6
    );

    transform:translateX(5px);
}

/* MAIN */

.main{
    margin-left:230px;
    padding:22px;
}

/* TOPBAR */

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:22px;
}

.topbar h1{
    font-size:34px;
    font-weight:800;
}

.subtitle{
    color:#94a3b8;
    font-size:13px;
    margin-top:5px;
}

.online{
    background:rgba(34,197,94,0.12);
    color:#22c55e;
    padding:10px 16px;
    border-radius:14px;
    font-size:13px;
    font-weight:700;
    border:1px solid rgba(34,197,94,0.2);
}

/* STATS */

.stats{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:18px;
    margin-bottom:20px;
}

.stat-card{
    position:relative;
    overflow:hidden;
    background:
    linear-gradient(
        145deg,
        rgba(15,23,42,0.95),
        rgba(30,41,59,0.85)
    );

    border:1px solid rgba(255,255,255,0.05);
    border-radius:24px;
    padding:22px;
    transition:0.3s;
}

.stat-card::before{
    content:'';
    position:absolute;
    width:120px;
    height:120px;
    background:rgba(59,130,246,0.12);
    border-radius:50%;
    top:-40px;
    right:-40px;
}

.stat-card:hover{
    transform:translateY(-5px);
    border-color:#3b82f6;
}

.stat-title{
    color:#94a3b8;
    font-size:13px;
    margin-bottom:10px;
}

.stat-value{
    font-size:40px;
    font-weight:800;
}

/* PANEL */

.panel{
    background:
    linear-gradient(
        145deg,
        rgba(15,23,42,0.95),
        rgba(2,6,23,0.9)
    );

    border:1px solid rgba(255,255,255,0.04);
    border-radius:24px;
    padding:20px;
    margin-bottom:20px;
}

.panel-title{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:18px;
}

.panel-title h3{
    font-size:22px;
    font-weight:700;
}

.live{
    background:#16a34a;
    padding:6px 14px;
    border-radius:999px;
    font-size:10px;
    font-weight:700;
}

/* TOP GRID */

.top-grid{
    display:grid;
    grid-template-columns:1.6fr 0.9fr;
    gap:18px;
    margin-bottom:20px;
}

/* SENSOR */

.sensor-item{
    background:rgba(15,23,42,0.9);
    border:1px solid rgba(255,255,255,0.04);
    padding:12px 16px;
    border-radius:18px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:10px;
    transition:0.3s;
}

.sensor-item:hover{
    transform:translateY(-3px);
    border-color:#38bdf8;
}

.sensor-left{
    display:flex;
    flex-direction:column;
}

.sensor-slot{
    font-weight:700;
    font-size:15px;
}

.sensor-status{
    font-size:11px;
    color:#94a3b8;
    margin-top:2px;
}

.sensor-distance{
    font-weight:800;
    font-size:20px;
}

/* SLOT */

.slot-grid{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:16px;
}

.slot-card{
    background:
    linear-gradient(
        145deg,
        rgba(15,23,42,0.9),
        rgba(30,41,59,0.8)
    );

    border-radius:20px;
    padding:16px;
    border:1px solid rgba(255,255,255,0.05);
    text-align:center;
    transition:0.3s;
}

.slot-card:hover{
    transform:translateY(-5px);
}

.slot-card.empty-border{
    border-color:rgba(34,197,94,0.4);
}

.slot-card.filled-border{
    border-color:rgba(239,68,68,0.4);
}

.slot-name{
    font-size:18px;
    font-weight:700;
    margin-bottom:10px;
}

.badge-slot{
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    font-size:10px;
    font-weight:700;
    margin-bottom:12px;
}

.badge-empty{
    background:#16a34a;
}

.badge-filled{
    background:#ef4444;
}

.car-icon{
    font-size:34px;
    margin-bottom:10px;
}

.slot-text{
    font-size:13px;
    color:#cbd5e1;
}

.slot-time{
    margin-top:4px;
    font-size:11px;
    color:#94a3b8;
}

/* CHART */

.chart-box{
    height:210px;
    display:flex;
    justify-content:center;
    align-items:center;
}

#parkingChart{
    max-width:190px !important;
    max-height:190px !important;
}

/* SEARCH */

.search-box{
    width:100%;
    background:#08152f;
    border:none;
    outline:none;
    padding:14px;
    border-radius:14px;
    color:white;
    margin-bottom:18px;
    border:1px solid rgba(255,255,255,0.05);
}

.search-box:focus{
    border-color:#3b82f6;
}

/* TABLE */

.table-modern{
    width:100%;
    border-collapse:collapse;
}

.table-modern th{
    color:#94a3b8;
    font-size:13px;
    padding:14px 10px;
    text-align:left;
}

.table-modern td{
    padding:16px 10px;
    border-top:1px solid rgba(255,255,255,0.05);
    font-size:14px;
}

.table-modern tr:hover{
    background:rgba(255,255,255,0.03);
}

.status{
    padding:5px 12px;
    border-radius:999px;
    font-size:10px;
    font-weight:700;
}

.status-filled{
    background:#ef4444;
}

.status-empty{
    background:#16a34a;
}

/* MOBILE */

@media(max-width:1200px){

    .slot-grid{
        grid-template-columns:repeat(2,1fr);
    }

    .stats{
        grid-template-columns:repeat(2,1fr);
    }

    .top-grid{
        grid-template-columns:1fr;
    }
}

@media(max-width:768px){

    .sidebar{
        display:none;
    }

    .main{
        margin-left:0;
    }

    .stats{
        grid-template-columns:1fr;
    }

    .slot-grid{
        grid-template-columns:1fr;
    }

    .topbar{
        flex-direction:column;
        align-items:flex-start;
        gap:12px;
    }

    .topbar h1{
        font-size:28px;
    }
}

</style>

</head>

<body>
 
<div class="sidebar">

    <div class="logo">
        SMART <br>
        <span>PARKING</span>
    </div>

    <div class="menu-title">
        MAIN MENU
    </div>

    <div class="menu">
        <a href="#Dashboard">Dashboard</a>
        <a href="#vehicle-db">Database Kendaraan</a>
        <a href="#slot-monitoring">Slot Monitoring</a>
        <a href="#sensor-distance">Sensor Distance</a>
        <a href="#parking-statistics">Parking Statistics</a>
    </div>

</div>

<div class="main">

    <!-- TOPBAR -->

    <div class="topbar">

        <div>
            <h1>Dashboard Overview</h1>

            <div class="subtitle">
                Real-time smart parking monitoring
            </div>
        </div>

        <div class="online">
            ● SYSTEM ONLINE
            <span id="clock"></span>
        </div>

    </div>

    <!-- STATS -->

    <div class="stats">

        <div class="stat-card">
            <div class="stat-title">Total Slot</div>
            <div class="stat-value" id="total-slot">0</div>
        </div>

        <div class="stat-card">
            <div class="stat-title">Slot Terisi</div>
            <div class="stat-value" id="filled-slot">0</div>
        </div>

        <div class="stat-card">
            <div class="stat-title">Slot Kosong</div>
            <div class="stat-value" id="empty-slot">0</div>
        </div>

        <div class="stat-card">
            <div class="stat-title">Device Online</div>
            <div class="stat-value">6/6</div>
        </div>

    </div>

    <!-- SENSOR + CHART -->

    <!-- VEHICLE DATABASE -->

<div class="panel" id="vehicle-db">

    <div class="panel-title">
        <h3>🗂 Database Kendaraan</h3>
    </div>

    <input
        type="text"
        id="searchPlate"
        class="search-box"
        placeholder="Cari plat nomor..."
    >

    <div style="overflow-x:auto;">

        <table class="table-modern">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Slot</th>
                    <th>Plat Nomor</th>
                    <th>Status</th>
                    <th>Waktu Masuk</th>
                    <th>Waktu Keluar</th>
                </tr>
            </thead>

            <tbody id="vehicle-table-body"></tbody>

        </table>

    </div>

</div>

<!-- SLOT MONITORING -->

<div class="panel" id="slot-monitoring">

    <div class="panel-title">
        <h3>🚗 Slot Monitoring</h3>

    </div>

    <div class="slot-grid" id="slot-container"></div>

</div>
<!-- SENSOR + CHART -->
<div class="top-grid">

    <!-- SENSOR -->

    <div class="panel" id="sensor-distance">

        <div class="panel-title">
            <h3>📡 Sensor Distance</h3>
        </div>

        <div id="distance-list"></div>

    </div>

  <!-- SENSOR + CHART -->

<div class="top-grid">

    <!-- PARKING STATISTICS -->

    <div class="panel" id="parking-statistics">

        <div class="panel-title">
            <h3>📊 Parking Statistics</h3>
        </div>

        <div class="chart-box">
            <canvas id="parkingChart"></canvas>
        </div>

    </div>

</div>

<script>

// CLOCK

function updateClock(){

    const now = new Date();

    document.getElementById('clock').innerHTML =
    ' | ' +
    now.toLocaleDateString('id-ID') +
    ' ' +
    now.toLocaleTimeString('id-ID');
}

setInterval(updateClock,1000);

updateClock();


// FETCH

async function fetchJson(url){

    const res = await fetch(url);

    return await res.json();
}


// CHART

const ctx =
document.getElementById('parkingChart');

const parkingChart = new Chart(ctx,{

    type:'doughnut',

    data:{
        labels:['Terisi','Kosong'],
        datasets:[{
            data:[0,0],
            backgroundColor:[
                '#ef4444',
                '#22c55e'
            ],
            borderWidth:0
        }]
    },

    options:{
        responsive:true,
        cutout:'75%',

        plugins:{
            legend:{
                labels:{
                    color:'white'
                }
            }
        }
    }
});


// UPDATE CHART

function updateChart(filled,empty){

    parkingChart.data.datasets[0].data =
    [filled,empty];

    parkingChart.update();
}


// LOAD SLOT

async function loadSlots(){

    const data =
    await fetchJson('api_get_slots.php');

    const container =
    document.getElementById('slot-container');

    container.innerHTML='';

    let filled=0;
    let empty=0;

    data.forEach(slot=>{

        const isFilled =
        slot.status === 'terisi';

        if(isFilled){
            filled++;
        }else{
            empty++;
        }

        container.innerHTML += `

        <div class="slot-card ${isFilled ? 'filled-border':'empty-border'}">

            <div class="slot-name">
                ${slot.nomor_slot}
            </div>

            <div class="badge-slot ${isFilled ? 'badge-filled':'badge-empty'}">
                ${isFilled ? 'TERISI':'KOSONG'}
            </div>

            <div class="car-icon">
                ${isFilled ? '🚘':'🅿️'}
            </div>

            <div class="slot-text">
                ${
                    isFilled
                    ?
                    slot.plat_nomor
                    :
                    'Slot Tersedia'
                }
            </div>

            <div class="slot-time">
                ${slot.waktu_masuk || ''}
            </div>

        </div>

        `;
    });

    document.getElementById('total-slot').innerHTML =
    data.length;

    document.getElementById('filled-slot').innerHTML =
    filled;

    document.getElementById('empty-slot').innerHTML =
    empty;

    updateChart(filled,empty);
}


// VEHICLE TABLE

async function loadVehicleTable(){

    const data =
    await fetchJson('api_get_slots.php');

    const tbody =
    document.getElementById('vehicle-table-body');

    tbody.innerHTML='';

    data.forEach(slot=>{

        tbody.innerHTML += `

        <tr>

            <td>${slot.id}</td>

            <td>${slot.nomor_slot}</td>

            <td>${slot.plat_nomor || '-'}</td>

            <td>
                <span class="status ${slot.status === 'terisi' ? 'status-filled':'status-empty'}">
                    ${slot.status}
                </span>
            </td>

            <td>${slot.waktu_masuk || '-'}</td>

            <td>${slot.waktu_keluar || '-'}</td>

        </tr>

        `;
    });
}


// DISTANCE

async function loadDistance(){

    const data =
    await fetchJson('api_get_distance.php');

    const container =
    document.getElementById('distance-list');

    container.innerHTML='';

    data.forEach(item=>{

        const detected =
        item.jarak < 20;

        container.innerHTML += `

        <div class="sensor-item">

            <div class="sensor-left">

                <div class="sensor-slot">
                    ${item.nomor_slot}
                </div>

                <div class="sensor-status">
                    ${detected ? 'Mobil Terdeteksi':'Slot Kosong'}
                </div>

            </div>

            <div class="sensor-distance"
                style="
                color:${detected ? '#ef4444':'#22c55e'}
                "
            >
                ${item.jarak} cm
            </div>

        </div>

        `;
    });
}


// SEARCH

document
.getElementById('searchPlate')
.addEventListener('keyup',function(){

    const value =
    this.value.toLowerCase();

    const rows =
    document.querySelectorAll(
        '#vehicle-table-body tr'
    );

    rows.forEach(row=>{

        row.style.display =
        row.innerText.toLowerCase().includes(value)
        ?
        ''
        :
        'none';
    });
});


// FIRST LOAD

loadSlots();
loadVehicleTable();
loadDistance();


// AUTO REFRESH

setInterval(loadSlots,3000);
setInterval(loadVehicleTable,3000);
setInterval(loadDistance,3000);

</script>

</body>
</html>