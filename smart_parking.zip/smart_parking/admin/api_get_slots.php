<?php
// api/api_get_slots.php
header('Content-Type: application/json');
include '../config.php';

$sql    = "SELECT * FROM slot_parkir ORDER BY nomor_slot";
$result = $conn->query($sql);

$data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

echo json_encode($data);
?>
