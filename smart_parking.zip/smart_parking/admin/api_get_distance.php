<?php

include "../config.php";

$query = mysqli_query($conn,"
SELECT nomor_slot, jarak
FROM slot_parkir
ORDER BY nomor_slot ASC
");

$data = [];

while($row = mysqli_fetch_assoc($query)){

    $data[] = $row;
}

header('Content-Type: application/json');

echo json_encode($data);