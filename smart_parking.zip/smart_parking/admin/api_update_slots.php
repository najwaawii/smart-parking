<?php
header('Content-Type: application/json');
include '../config.php';

$id_slot = $_POST['id']  ?? null;
$aksi    = $_POST['aksi'] ?? null;

if (!$id_slot || !$aksi) {
    echo json_encode(['success' => false, 'message' => 'parameter kurang']);
    exit;
}

if ($aksi === 'masuk') {
    // ambil plat terakhir dari log_anpr
    $plat = 'UNKNOWN';
    $q = "SELECT plat_nomor FROM log_anpr ORDER BY waktu_deteksi DESC LIMIT 1";
    $r = $conn->query($q);
    if ($r && $r->num_rows > 0) {
        $row  = $r->fetch_assoc();
        $plat = $row['plat_nomor'];
    }

    $now = date('Y-m-d H:i:s');

    $sql = "UPDATE slot_parkir 
            SET status='terisi',
                plat_nomor='$plat',
                waktu_masuk='$now',
                waktu_keluar=NULL
            WHERE id='$id_slot'";
} elseif ($aksi === 'keluar') {
    $now = date('Y-m-d H:i:s');
    $sql = "UPDATE slot_parkir 
            SET status='kosong',
                waktu_keluar='$now'
            WHERE id='$id_slot'";
} else {
    echo json_encode(['success' => false, 'message' => 'aksi tidak dikenal']);
    exit;
}

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>
