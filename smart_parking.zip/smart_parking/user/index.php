<?php
// index.php
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Smart Parking Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Inter',sans-serif;

    height:100vh;

    overflow:hidden;

    background:
    radial-gradient(circle at top left,#1e3a8a 0%,#0f172a 40%,#020617 100%);

    color:white;
}

/* ========================= */
/* WRAPPER */
/* ========================= */

.dashboard-wrapper{
    max-width:1400px;

    margin:auto;

    padding:12px;

    height:100vh;

    display:flex;
    flex-direction:column;
}

/* ========================= */
/* TITLE */
/* ========================= */

.hero-title{
    font-size:1.9rem;
    font-weight:800;

    margin-bottom:12px;
}

/* ========================= */
/* STATS */
/* ========================= */

.stats-grid{
    display:grid;

    grid-template-columns:repeat(3,1fr);

    gap:12px;

    margin-bottom:12px;
}

.stat-card{
    padding:12px;

    border-radius:18px;

    background:rgba(255,255,255,0.05);

    border:1px solid rgba(255,255,255,0.08);

    backdrop-filter:blur(14px);
}

.stat-label{
    color:#94a3b8;
    font-size:0.9rem;
}

.stat-value{
    font-size:1.7rem;
    font-weight:800;
}

/* ========================= */
/* MAIN */
/* ========================= */

.glass-card{
    flex:1;

    background:rgba(15,23,42,0.72);

    border:1px solid rgba(255,255,255,0.08);

    border-radius:24px;

    padding:16px;

    backdrop-filter:blur(20px);

    overflow:hidden;
}

/* ========================= */
/* LEGEND */
/* ========================= */

.legend{
    display:flex;

    gap:18px;

    margin-bottom:16px;
}

.legend-item{
    display:flex;
    align-items:center;
    gap:8px;

    font-weight:600;
}

.legend-dot{
    width:12px;
    height:12px;

    border-radius:50%;
}

.dot-green{
    background:#22c55e;
}

.dot-red{
    background:#ef4444;
}

/* ========================= */
/* SLOT GRID */
/* ========================= */

.slot-grid{
    display:grid;

    grid-template-columns:
    repeat(3, minmax(260px, 1fr));

    gap:18px;

    width:100%;

    align-items:start;
}

/* ========================= */
/* SLOT CARD */
/* ========================= */

.parking-card{
    min-height:185px;

    border-radius:20px;

    padding:10px;

    position:relative;

    overflow:hidden;

    display:flex;
    flex-direction:column;
    justify-content:space-between;

    backdrop-filter:blur(12px);

    transition:0.3s ease;
}

/* EMPTY */

.parking-card.empty{
    background:
    linear-gradient(
        135deg,
        rgba(34,197,94,0.16),
        rgba(34,197,94,0.08)
    );

    border:2px solid rgba(34,197,94,0.35);

    box-shadow:
    0 0 18px rgba(34,197,94,0.12);
}

/* FILLED */

.parking-card.filled{
    background:
    linear-gradient(
        135deg,
        rgba(239,68,68,0.18),
        rgba(127,29,29,0.25)
    );

    border:2px solid rgba(239,68,68,0.35);

    box-shadow:
    0 0 18px rgba(239,68,68,0.15);
}

/* ========================= */
/* SLOT NAME */
/* ========================= */

.slot-name{
    font-size:1.1rem;
    font-weight:800;

    margin-bottom:6px;
}

/* ========================= */
/* PARKING AREA */
/* ========================= */

.parking-area{
    position:relative;

    height:52px;

    border-radius:12px;

    overflow:hidden;

    display:flex;
    justify-content:center;
    align-items:center;

    margin-bottom:8px;
}

.parking-area.empty{
    background:rgba(34,197,94,0.08);
}

.parking-area.filled{
    background:rgba(239,68,68,0.08);
}

.parking-lines{
    position:absolute;
    inset:0;

    background-image:
    linear-gradient(to right,rgba(255,255,255,0.08) 2px,transparent 2px),
    linear-gradient(to bottom,rgba(255,255,255,0.08) 2px,transparent 2px);

    background-size:28px 28px;

    opacity:0.2;
}

.sensor-pulse{
    position:absolute;
    top:14px;
    right:14px;

    width:14px;
    height:14px;

    border-radius:50%;

    animation:pulse 1.5s infinite;
}

/* warna dot */

.empty .sensor-pulse{
    background:#22c55e;
    box-shadow:0 0 12px #22c55e;
}

.filled .sensor-pulse{
    background:#ef4444;
    box-shadow:0 0 12px #ef4444;
}
@keyframes pulse{
    0%{
        transform:scale(1);
        opacity:1;
    }
    70%{
        transform:scale(2.2);
        opacity:0;
    }
    100%{
        transform:scale(1);
        opacity:0;
    }
}

.empty .sensor-pulse{
    background:#22c55e;
}

.filled .sensor-pulse{
    background:#ef4444;
}

.parking-label{
    position:absolute;

    top:6px;
    left:6px;

    padding:2px 7px;

    border-radius:999px;

    background:rgba(255,255,255,0.08);

    font-size:0.62rem;
    font-weight:700;
}

.car{
    font-size:3rem;
    z-index:2;
}

.parking-road{
    position:absolute;

    bottom:0;

    width:100%;
    height:16px;

    background:#1e293b;

    border-top:2px dashed rgba(255,255,255,0.2);
}

/* ========================= */
/* STATUS */
/* ========================= */

.slot-status{
    display:inline-flex;
    align-items:center;

    gap:6px;

    width:max-content;

    padding:4px 8px;

    border-radius:999px;

    font-size:0.68rem;
    font-weight:700;

    margin-bottom:5px;
}

.status-empty{
    background:rgba(34,197,94,0.15);
    color:#4ade80;
}

.status-filled{
    background:rgba(239,68,68,0.15);
    color:#f87171;
}

.time-box{
    font-size:0.62rem;

    color:#cbd5e1;

    margin-bottom:8px;
}

/* ========================= */
/* BUTTON */
/* ========================= */

.slot-button{
    width:100%;

    border:none;

    border-radius:10px;

    padding:7px 5px;

    font-size:0.72rem;
    font-weight:700;

    color:white;

    margin-top:4px;
}

.btn-empty{
    background:
    linear-gradient(135deg,#22c55e,#16a34a);
}

.btn-filled{
    background:
    linear-gradient(135deg,#ef4444,#dc2626);
}

/* ========================= */
/* MOBILE */
/* ========================= */

@media(max-width:1000px){

    body{
        overflow:auto;
    }

    .slot-grid{
        grid-template-columns:repeat(2,1fr);
    }
}

@media(max-width:700px){

    body{
        overflow:auto;
    }

    .stats-grid{
        grid-template-columns:1fr;
    }

    .slot-grid{
        grid-template-columns:1fr;
    }

    .hero-title{
        font-size:1.6rem;
    }
}

</style>
</head>

<body>

<div class="dashboard-wrapper">

    <div class="hero-title">
        SMART PARKING SLOT
    </div>

    <!-- STATS -->
    <div class="stats-grid">

        <div class="stat-card">
            <div class="stat-label">Total Slot</div>
            <div class="stat-value" id="total-slot">0</div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Slot Kosong</div>
            <div class="stat-value text-success" id="slot-kosong">0</div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Slot Terisi</div>
            <div class="stat-value text-danger" id="slot-terisi">0</div>
        </div>

    </div>

    <!-- SLOT -->
    <div class="glass-card">

        <div class="legend">

            <div class="legend-item">
                <div class="legend-dot dot-green"></div>
                Kosong
            </div>

            <div class="legend-item">
                <div class="legend-dot dot-red"></div>
                Terisi
            </div>

        </div>

        <div id="slot-container" class="slot-grid"></div>

    </div>

</div>

<script>

async function fetchJson(url, options = {}) {

    const res = await fetch(url, options);

    const text = await res.text();

    console.log(text);

    return JSON.parse(text);
}

async function updateSlot(id, aksi){

    const fd = new FormData();

    fd.append('id', id);
    fd.append('aksi', aksi);

    const result = await fetchJson(
        'api_update_slots.php',
        {
            method:'POST',
            body:fd
        }
    );

    if(result.success){

        loadSlots();

    }else{

        alert('Gagal update slot');
    }
}

async function loadSlots(){

    const data =
        await fetchJson('api_get_slots.php');

    const container =
        document.getElementById('slot-container');

    container.innerHTML = '';

    let kosong = 0;
    let terisi = 0;

    data.forEach(slot => {

        const isFilled =
            slot.status === 'terisi';

        if(isFilled){

            terisi++;

        }else{

            kosong++;
        }

        const col = document.createElement('div');

        col.innerHTML = `

        <div class="parking-card ${isFilled ? 'filled' : 'empty'}">

            <div>

                <div class="slot-name">
                    Slot ${slot.nomor_slot}
                </div>

                <div class="parking-area ${isFilled ? 'filled' : 'empty'}">

                    <div class="parking-lines"></div>

                    <div class="sensor-pulse"></div>

                    <div class="parking-label">
                        ${slot.nomor_slot}
                    </div>

                    <div class="car">
                        ${isFilled ? '🚗' : '🅿️'}
                    </div>

                    <div class="parking-road"></div>

                </div>

                <div class="slot-status ${isFilled ? 'status-filled' : 'status-empty'}">

                    ${isFilled ? '● TERISI' : '● KOSONG'}

                </div>

                <div class="time-box">

                    ${
                        isFilled
                        ?
                        'Slot sedang digunakan'
                        :
                        'Slot tersedia'
                    }

                </div>

            </div>

            <button
                class="slot-button ${isFilled ? 'btn-filled' : 'btn-empty'}"
                onclick="updateSlot(${slot.id}, '${isFilled ? 'keluar' : 'masuk'}')">

                ${isFilled ? 'Mobil Keluar' : 'Parkir'}

            </button>

        </div>

        `;

        container.appendChild(col);

    });

    document.getElementById('total-slot').innerText =
        data.length;

    document.getElementById('slot-kosong').innerText =
        kosong;

    document.getElementById('slot-terisi').innerText =
        terisi;
}

loadSlots();

setInterval(loadSlots, 3000);

</script>

</body>
</html>