<?php
// config.php
date_default_timezone_set('Asia/Jakarta');

$host = '172.20.10.4';
$user = 'root';       // default XAMPP
$pass = '';           // sesuaikan jika ada password
$db   = 'db_parkir';  // nama database

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die('Koneksi database gagal: ' . $conn->connect_error);
}
?>
